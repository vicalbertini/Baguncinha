DROP TABLE IF EXISTS pais;
CREATE TABLE pais
(
	id int AUTO_INCREMENT NOT NULL PRIMARY KEY,
    nome varchar (100) NOT NULL,
    populacao bigint NOT NULL,
    area numeric (15,2) NOT NULL
 );

INSERT INTO pais (id, nome, populacao, area) 

VALUES 
(1, 'Estados Unidos', 32720000, 1,1),
(2, 'Nauru', 9771, 1,1),
(3, 'Monaco', 32020, 1,1),
(4, 'Liechtenstein', 35010, 1,1),
(5, 'Seychelles', 84600, 1,1)